#ifndef SF_PRINTF
#define SF_PRINTF

void sf_printf (const char *fmt, ...);
void sf_errprintf (const char *fmt, ...);

#endif
